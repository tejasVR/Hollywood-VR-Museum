Hi!

I spent about 6-7 hours from start to finish on this project, and went through many challenges/ideas along the way! I am using Unity version 5.5.4f1 and GVR version 1.3. The most challenging thing was learning how to optimize the application for mobile phones, since a combination of baked and realtime lighting is used, as well as a myriad of 3d models. I enjoyed creating each exhbit, and giving each one some flavor (especially the ones with 3d models!).

Best,
Tejas